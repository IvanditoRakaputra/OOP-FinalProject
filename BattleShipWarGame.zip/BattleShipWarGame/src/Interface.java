import javax.swing.*;
public interface Interface {
    public static boolean isHit(JLabel ship, int x, int y) {
        return false;
    }
}
