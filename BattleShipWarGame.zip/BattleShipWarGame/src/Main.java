// This is the main method that is automatically executed when the program starts.
public class Main {
    public static void main(String[] args) {
        new GameGUI();
    }
}